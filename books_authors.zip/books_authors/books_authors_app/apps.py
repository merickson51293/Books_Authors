from django.apps import AppConfig


class BooksAuthorsAppConfig(AppConfig):
    name = 'books_authors_app'
